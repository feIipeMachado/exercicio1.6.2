import "./styles.css";
import { useState } from "react";

export default function App() {
  const [tarefa, setTarefa] = useState("");
  const [tarefas, setTarefas] = useState([]);

  const onDigitar = (event) => {
    setTarefa(event.target.value);
  };

  const onAdicionar = () => {
    setTarefas([...tarefas, tarefa]);
  };

  const onDeletar = (tarefaClique) => {
    setTarefas(
      tarefas.filter((tarefaDiferente) => tarefaDiferente !== tarefaClique)
    );
  };

  return (
    <div className="App">
      <input onChange={onDigitar} />
      <button onClick={onAdicionar}>adicionar</button>
      {tarefas.map((tarefa) => (
        <div>
          <p>{tarefa}</p>
          <button onClick={() => onDeletar(tarefa)}>excluir</button>
        </div>
      ))}
    </div>
  );
}
